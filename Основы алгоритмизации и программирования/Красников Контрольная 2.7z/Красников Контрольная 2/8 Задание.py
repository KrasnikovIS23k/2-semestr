def lol(number, lower, upper):
    return lower <= number <= upper
print(lol(5, 1, 10))
print(lol(10, 1, 10))
print(lol(15, 1, 10))
